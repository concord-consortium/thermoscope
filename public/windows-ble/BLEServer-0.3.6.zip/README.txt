Windows 10 Web Bluetooth Polyfill Native Messaging Server

https://github.com/urish/web-bluetooth-polyfill

# Installation:

1. Create a folder named C:\Program Files (x86)\Web Bluetooth Polyfill
2. Extract all the files there
3. Run `register.cmd` to register the nativeMessaging server

# License

Copyright (C) 2017, Uri Shaked. Licensed under the terms of MIT license.
